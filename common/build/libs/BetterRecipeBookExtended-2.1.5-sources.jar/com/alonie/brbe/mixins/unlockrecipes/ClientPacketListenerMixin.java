package com.alonie.brbe.mixins.unlockrecipes;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.interfaces.unlockrecipes.IMixinRecipeManager;
import com.alonie.brbe.mixins.accessors.RecipeBookComponentAccessor;
import com.alonie.brbe.util.BookStateCache;
import com.alonie.brbe.util.IncompatibleCraftingUtil;
import com.alonie.brbe.util.PartialCraftingUtil;
import com.alonie.brbe.util.RecipeIndex;
import com.alonie.brbe.util.RecipeMenuUtil;
import com.alonie.brbe.util.RecipeUnlockUtil;
import com.alonie.recipebookispain_extended.RecipeBookIsPain;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.recipebook.RecipeUpdateListener;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundContainerSetSlotPacket;
import net.minecraft.network.protocol.game.ClientboundPlaceGhostRecipePacket;
import net.minecraft.network.protocol.game.ClientboundRecipePacket;
import net.minecraft.network.protocol.game.ClientboundUpdateRecipesPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.inventory.RecipeBookMenu;
import net.minecraft.world.item.crafting.RecipeManager;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Set;

/**
 * Unlocks all recipes that are sent to the client or updated by either the local server or external server
 */
@Mixin(ClientPacketListener.class)
public abstract class ClientPacketListenerMixin {

    @Shadow @Final private RecipeManager recipeManager;
    @Unique private Minecraft _$minecraft = Minecraft.getInstance();

    @Inject(method = "handleAddOrRemoveRecipes", at = @At(value = "RETURN"))
    public void onAddOrRemoveRecipes(ClientboundRecipePacket packet, CallbackInfo ci) {
        Set<ResourceLocation> serverUnlockedRecipes = ((IMixinRecipeManager) recipeManager).brbe$getServerUnlockedRecipes();
        boolean invalidateCaches = false;
        switch (packet.getState()) {
            case INIT:
                serverUnlockedRecipes.clear();
                PartialCraftingUtil.clearCaches();
                IncompatibleCraftingUtil.clearCaches();
                BookStateCache.clear();
                RecipeIndex.clear();
                invalidateCaches = true;
                // fall through to ADD
            case ADD:
                if (!packet.getRecipes().isEmpty()) {
                    serverUnlockedRecipes.addAll(packet.getRecipes());
                    if (!invalidateCaches) RecipeBookIsPain.recipeGeneration++;
                }
                break;
            case REMOVE:
                if (!packet.getRecipes().isEmpty()) {
                    packet.getRecipes().forEach(serverUnlockedRecipes::remove);
                    RecipeBookIsPain.recipeGeneration++;
                }
                break;
        }
        RecipeUnlockUtil.unlockRecipesIfRequired();
    }

    @Inject(method = "handleUpdateRecipes", at = @At(value = "RETURN"))
    public void onUpdateRecipes(ClientboundUpdateRecipesPacket packet, CallbackInfo ci) {
        // Recipe manager was reloaded (datapack reload / server sync) —
        // invalidate all caches since recipe IDs may have changed.
        PartialCraftingUtil.clearCaches();
        IncompatibleCraftingUtil.clearCaches();
        BookStateCache.clear();
        RecipeIndex.clear();
        RecipeBookIsPain.recipeGeneration++;
        RecipeUnlockUtil.unlockRecipesIfRequired();
    }

    @Inject(method = "handleContainerSetSlot", at = @At(value = "HEAD"))
    public void onContainerSetSlot(ClientboundContainerSetSlotPacket packet, CallbackInfo ci) {
        // clear ghost recipes if crafting grid contents are changed by server
        if (BetterRecipeBook.ctx().config().newRecipes.unlockAll && _$minecraft.player != null
                && _$minecraft.player.containerMenu instanceof RecipeBookMenu<?, ?> menu
                && _$minecraft.player.containerMenu.containerId == packet.getContainerId()
                && _$minecraft.screen instanceof RecipeUpdateListener rul) {
            if (!packet.getItem().isEmpty() && RecipeMenuUtil.isRecipeSlot(menu, packet.getSlot())) {
                ((RecipeBookComponentAccessor) rul.getRecipeBookComponent()).getGhostRecipe().clear();
            }
        }
    }

    @Inject(method = "handlePlaceRecipe", at = @At(value = "HEAD", target = "Lnet/minecraft/client/gui/screens/recipebook/RecipeBookComponent;setupGhostRecipe(Lnet/minecraft/world/item/crafting/Recipe;Ljava/util/List;)V"))
    public void onHandlePlaceRecipe_setupGhostRecipe(ClientboundPlaceGhostRecipePacket packet, CallbackInfo ci) {
        if (_$minecraft.screen instanceof RecipeUpdateListener rul) {
            ((RecipeBookComponentAccessor) rul.getRecipeBookComponent()).getGhostRecipe().clear();
        }
    }


}
