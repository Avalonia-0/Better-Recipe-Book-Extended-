package com.alonie.brbe.generic;

import com.google.common.collect.Lists;
import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.api.BRBBookCategories;
import com.alonie.brbe.api.BRBBookSettings;
import com.alonie.brbe.compat.ItemViewCompat;
import com.alonie.brbe.interfaces.IPinningComponent;
import com.alonie.brbe.interfaces.ISettingsButton;
import com.alonie.brbe.mixins.accessors.RecipeBookComponentAccessor;
import com.alonie.brbe.search.SearchCache;
import com.alonie.brbe.search.SearchQuery;
import com.alonie.brbe.util.BRBHelper;
import com.alonie.brbe.util.BRBTextures;
import com.alonie.brbe.util.BrbeLogger;
import com.alonie.brbe.util.CollectionPipeline;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.*;
import net.minecraft.client.gui.components.events.GuiEventListener;
import net.minecraft.client.gui.narration.NarratableEntry;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.gui.screens.recipebook.RecipeShownListener;
import net.minecraft.client.resources.language.LanguageInfo;
import net.minecraft.client.resources.language.LanguageManager;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.StackedContents;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeHolder;
import net.minecraft.world.item.crafting.RecipeManager;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.*;
import java.util.function.Consumer;

public abstract class GenericRecipeBookComponent<M extends AbstractContainerMenu, C extends GenericRecipeBookCollection<R, M>, R extends GenericRecipe> implements Renderable, NarratableEntry, GuiEventListener, ISettingsButton, RecipeShownListener, IPinningComponent<C> {
    protected static final Component SEARCH_HINT = RecipeBookComponentAccessor.getSEARCH_HINT();
    protected static final Component ALL_RECIPES_TOOLTIP = RecipeBookComponentAccessor.getALL_RECIPES_TOOLTIP();

    /** Vanilla recipe book texture dimensions. */
    public static final int VANILLA_BOOK_WIDTH = 147;
    public static final int VANILLA_BOOK_HEIGHT = 166;

    boolean visible;
    protected boolean ignoreTextInput;
    protected Minecraft minecraft;
    protected EditBox searchBox;
    private String lastSearch;
    protected int xOffset;
    protected boolean widthTooNarrow;
    protected int width;
    protected int height;
    /** Container screen's imageWidth (typically 176). Used for expanded book width calculation. */
    protected int containerImageWidth = 176;
    protected M menu;
    protected final StackedContents stackedContents = new StackedContents();
    protected StateSwitchingButton filterButton;
    protected ImageButton settingsButton;
    @Nullable
    protected ImageButton expandedToggleButton;
    public GenericRecipePage<M, C, R> recipesPage;
    protected final List<BRBGroupButtonWidget> tabButtons = Lists.newArrayList();
    @Nullable
    public BRBGroupButtonWidget selectedTab;
    protected GenericClientRecipeBook book;
    protected RecipeManager recipeManager;

    private boolean doubleRefresh = true;
    protected RegistryAccess registryAccess;
    @Nullable
    public GenericGhostRecipe<R> ghostRecipe;

    /** The ghost ingredient ItemStack the mouse was over during the last tooltip render. */
    @Nullable
    private ItemStack brbe$lastHoveredGhostItem;

    protected GenericRecipeBookComponent() {
    }

    abstract public Component getRecipeFilterName();

    abstract public BRBHelper.Book getRecipeBookType();

    public void init(int parentWidth, int parentHeight, Minecraft client, boolean narrow, M menu, RegistryAccess registryAccess) {
        this.init(parentWidth, parentHeight, client, narrow, menu, null, registryAccess);
    }

    public void init(int width, int height, Minecraft minecraft, boolean widthNarrow, M menu, @Nullable Consumer<ItemStack> onGhostRecipeUpdate, RegistryAccess registryAccess) {
        this.minecraft = minecraft;
        this.width = width;
        this.height = height;
        this.menu = menu;
        this.widthTooNarrow = widthNarrow;
        if (this.minecraft.player == null) return;
        this.minecraft.player.containerMenu = menu;

        this.setVisible(BRBBookSettings.isOpen(this.getRecipeBookType()));

        this.book = new GenericClientRecipeBook();
        this.registryAccess = registryAccess;

        this.ghostRecipe = new GenericGhostRecipe<>(onGhostRecipeUpdate, registryAccess);
    }

    public void initVisuals() {
        if (BetterRecipeBook.config.keepCentered) {
            this.xOffset = this.widthTooNarrow ? 0 : 162;
        } else {
            this.xOffset = this.widthTooNarrow ? 0 : 86;
        }

        int bookWidth = getCurrentBookWidth();
        int i = getBookLeft();
        int j = getBookTop();
        this.stackedContents.clear();
        if (this.minecraft.player == null) return;
        this.minecraft.player.getInventory().fillStackedContents(this.stackedContents);
        // TODO: menu.fillCraftSlotsStackedContents(this.stackedContents);
        String string = this.searchBox != null ? this.searchBox.getValue() : "";
        Objects.requireNonNull(this.minecraft.font);
        int searchWidth = isExpanded() ? bookWidth - 140 : 81;
        this.searchBox = new EditBox(this.minecraft.font, i + 25, j + 13, searchWidth,
                this.minecraft.font.lineHeight + 5, Component.translatable("itemGroup.search"));
        this.searchBox.setMaxLength(50);
        this.searchBox.setVisible(true);
        this.searchBox.setTextColor(0xFFFFFF);
        this.searchBox.setValue(string);
        this.searchBox.setHint(SEARCH_HINT);
        this.settingsButton = createSettingsButton(i, j);
        this.recipesPage.initialize(this.minecraft, i, j, menu, bookWidth);
        this.tabButtons.clear();
        // filter button: right-aligned from the book's right edge
        this.filterButton = new StateSwitchingButton(i + bookWidth - 37, j + 12, 26, 16,
                BRBBookSettings.isFiltering(this.getRecipeBookType()));
        this.updateFilterButtonTooltip();
        this.filterButton.initTextureValues(BRBTextures.RECIPE_BOOK_FILTER_BUTTON_SPRITES);

        List<BRBBookCategories.Category> categories = BRBBookCategories.getCategories(this.getRecipeBookType());

        if (categories == null) throw new NullPointerException("Book category not registered");

        for (BRBBookCategories.Category category : categories) {
            this.tabButtons.add(new BRBGroupButtonWidget(category));
        }

        if (this.selectedTab != null) {
            this.selectedTab = this.tabButtons.stream().filter((button) -> button.getCategory().equals(this.selectedTab.getCategory())).findFirst().orElse(null);
        }

        if (this.selectedTab == null) {
            this.selectedTab = this.tabButtons.get(0);
        }

        this.selectedTab.setStateTriggered(true);
        this.updateCollections(false);
        this.refreshTabButtons();
        this.refreshExpandedToggleButton();
    }

    public void render(GuiGraphics gui, int mouseX, int mouseY, float delta) {
        if (!this.isVisible()) return;

        // Log render state before any processing
        BrbeLogger.log(BrbeLogger.Category.RENDER,
                "Generic render ENTER — configChanged=%s, visible=%s, doubleRefresh=%s",
                BetterRecipeBook.configChanged, visible, doubleRefresh);

        if (this.doubleRefresh) {
            // Minecraft doesn't populate the inventory on initialization so this is the only solution I have
            updateCollections(true);
            this.doubleRefresh = false;
        }

        // When config changes (e.g. enablePinning, noGrouped toggled in the
        // Cloth Config screen), reset recipe visibility state and do a full
        // re-initialization so all UI elements and recipe ordering match.
        if (BetterRecipeBook.configChanged) {
            BrbeLogger.log(BrbeLogger.Category.RENDER,
                    "Generic render — configChanged CONSUMED, calling initVisuals");
            // Reset filter state: show all recipes after a config change,
            // letting the pipeline handle sorting.  The user can re-toggle
            // the filter button to their preference afterward.
            BRBBookSettings.setFiltering(this.getRecipeBookType(), false);
            initVisuals();
            BetterRecipeBook.configChanged = false;
        }

        gui.pose().pushPose();
        gui.pose().translate(0.0f, 0.0f, 100.0f);

        // Render recipe book background using 3-slice: left/right caps at
        // native size, middle section tiled.  Avoids distorting borders.
        int bookWidth = getCurrentBookWidth();
        int blitX = getBookLeft();
        int blitY = getBookTop();
        brbe$renderBookBackground(gui, blitX, blitY, bookWidth);

        // render search box
        this.searchBox.render(gui, mouseX, mouseY, delta);

        // render tab buttons
        for (BRBGroupButtonWidget widget : this.tabButtons) {
            widget.render(gui, mouseX, mouseY, delta);
        }

        this.filterButton.render(gui, mouseX, mouseY, delta);

        if (this.expandedToggleButton != null) {
            this.expandedToggleButton.render(gui, mouseX, mouseY, delta);
        }

        ISettingsButton.super.renderSettingsButton(this.settingsButton, gui, mouseX, mouseY, delta);

        // render the recipe book page contents
        this.recipesPage.render(gui, blitX, blitY, mouseX, mouseY, delta);

        gui.pose().popPose();
    }

    @Override
    public boolean keyPressed(int i, int j, int k) {
        this.ignoreTextInput = false;
        if (!this.isVisible() || this.minecraft.player != null && this.minecraft.player.isSpectator()) {
            return false;
        }
        if (this.searchBox.keyPressed(i, j, k)) {
            this.checkSearchStringUpdate();
            return true;
        }
        if (this.searchBox.isFocused() && this.searchBox.isVisible() && i != 256) {
            return true;
        }
        if (this.minecraft.options.keyChat.matches(i, j) && !this.searchBox.isFocused()) {
            this.ignoreTextInput = true;
            this.searchBox.setFocused(true);
            return true;
        }

        if (BetterRecipeBook.PIN_MAPPING.matches(i, j) && BetterRecipeBook.config.enablePinning) {
            for (GenericRecipeButton<C, R, M> resultButton : this.recipesPage.getButtons()) {
                if (resultButton.isHoveredOrFocused()) {
                    BetterRecipeBook.pinnedRecipeManager.addOrRemoveFavourite(resultButton.getCollection());
                    this.updateCollections(false);
                    return true;
                }
            }
        }

        // JEI/REI integration: open recipe/usage views for hovered item
        if (ItemViewCompat.isLoaded()) {
            // ── 1. Recipe buttons ──────────────────────────────────────
            if (this.recipesPage.hoveredButton != null) {
                R hoveredRecipe = this.recipesPage.hoveredButton.getCurrentDisplayedRecipe();
                if (hoveredRecipe != null) {
                    ItemStack hoveredStack = hoveredRecipe.getResult(registryAccess, this.recipesPage.hoveredButton.category);
                    if (BetterRecipeBook.RECIPE_VIEW_MAPPING.matches(i, j)) {
                        return ItemViewCompat.openRecipeView(hoveredStack);
                    }
                    if (BetterRecipeBook.USAGE_VIEW_MAPPING.matches(i, j)) {
                        return ItemViewCompat.openUsageView(hoveredStack);
                    }
                }
            }

            // ── 2. Ghost items ─────────────────────────────────────────
            ItemStack ghostStack = this.brbe$lastHoveredGhostItem;
            if (ghostStack != null && !ghostStack.isEmpty()) {
                if (BetterRecipeBook.RECIPE_VIEW_MAPPING.matches(i, j)) {
                    return ItemViewCompat.openRecipeView(ghostStack);
                }
                if (BetterRecipeBook.USAGE_VIEW_MAPPING.matches(i, j)) {
                    return ItemViewCompat.openUsageView(ghostStack);
                }
            }
        }

        return false;
    }

    public abstract void handlePlaceRecipe();

    @Override
    public boolean keyReleased(int i, int j, int k) {
        this.ignoreTextInput = false;
        return GuiEventListener.super.keyReleased(i, j, k);
    }

    @Override
    public boolean charTyped(char c, int i) {
        if (this.ignoreTextInput) {
            return false;
        }
        if (!this.isVisible() || this.minecraft.player != null && this.minecraft.player.isSpectator()) {
            return false;
        }
        if (this.searchBox.charTyped(c, i)) {
            this.checkSearchStringUpdate();
            return true;
        }
        return GuiEventListener.super.charTyped(c, i);
    }

    private void checkSearchStringUpdate() {
        String string = this.searchBox.getValue().toLowerCase(Locale.ROOT);
        this.pirateSpeechForThePeople(string);
        if (!string.equals(this.lastSearch)) {
            this.updateCollections(false);
            this.lastSearch = string;
        }
    }

    protected void updateCollections(boolean resetPageNumber) {
        if (this.selectedTab == null) return;
        if (this.searchBox == null) return;

        BrbeLogger.log(BrbeLogger.Category.STATE,
                "updateCollections ENTER (generic) — pCE=%s, pME=%s, eP=%s, isFiltering=%s, collections=%d",
                BetterRecipeBook.config.partialCraftingEnabled,
                BetterRecipeBook.config.partialMarkingEnabled,
                BetterRecipeBook.config.enablePinning,
                BRBBookSettings.isFiltering(this.getRecipeBookType()),
                this.getCollectionsForCategory().size());

        List<C> results = new ArrayList<>(this.getCollectionsForCategory());

        // Search filter — kept inline because result-item extraction
        // differs fundamentally between vanilla and generic recipe types.
        String string = this.searchBox.getValue();
        if (!string.isEmpty()) {
            SearchQuery query = SearchQuery.parse(string);
            SearchCache cache = new SearchCache();
            results.removeIf(collection -> !matchesSearch(collection, query, cache));
        }

        // Delegate pin sort, partial sort, and filter toggle to the
        // unified CollectionPipeline.  C extends GenericRecipeBookCollection
        // which implements PipelineCollection, so the generic overloads
        // work directly.
        //
        // Pin sort always applies (pinning is filter-independent).
        // Partial sort applies when partialCraftingEnabled is ON (BRBE
        // manages filtering) OR when the user has toggled the filter ON.
        CollectionPipeline.applyPinsGeneric(results);

        boolean isFiltering = BRBBookSettings.isFiltering(this.getRecipeBookType());
        boolean shouldSort = BetterRecipeBook.config.partialCraftingEnabled || isFiltering;
        if (shouldSort) {
            results = CollectionPipeline.applyPartialSortGeneric(results);
        }
        results = CollectionPipeline.applyFilterToggleGeneric(results, shouldSort);

        BrbeLogger.log(BrbeLogger.Category.STATE,
                "updateCollections EXIT (generic) — shouldSort=%s, resultCount=%d",
                shouldSort, results.size());

        this.recipesPage.setResults(results, resetPageNumber, selectedTab.getCategory());
    }

    private boolean matchesSearch(C collection, SearchQuery query, SearchCache cache) {
        for (R recipe : collection.getRecipes()) {
            ItemStack result = recipe.getResult(registryAccess, selectedTab.getCategory());
            if (result != null && !result.isEmpty() && query.matches(result, cache)) {
                return true;
            }
        }
        return false;
    }

    private void pirateSpeechForThePeople(String string) {
        if ("excitedze".equals(string)) {
            LanguageManager languageManager = this.minecraft.getLanguageManager();
            String string2 = "en_pt";
            LanguageInfo languageInfo = languageManager.getLanguage("en_pt");
            if (languageInfo == null || languageManager.getSelected().equals("en_pt")) {
                return;
            }
            languageManager.setSelected("en_pt");
            this.minecraft.options.languageCode = "en_pt";
            this.minecraft.reloadResourcePacks();
            this.minecraft.options.save();
        }
    }

    private boolean isOffsetNextToMainGUI() {
        return this.xOffset == 86;
    }

    // ── Expanded recipe book ───────────────────────────────────────

    /** Whether the recipe book is currently in expanded (full-width) mode. */
    public boolean isExpanded() {
        return BetterRecipeBook.config.expandedRecipeBook
                && !this.widthTooNarrow
                && this.isVisible();
    }

    /**
     * The left-edge X coordinate of the recipe book.  Always computed from
     * the vanilla 147px width so the left side stays fixed regardless of
     * expanded mode.  Expansion only extends the right edge.
     */
    public int getBookLeft() {
        return (this.width - VANILLA_BOOK_WIDTH) / 2 - this.xOffset;
    }

    /** The top-edge Y coordinate of the recipe book. */
    public int getBookTop() {
        return (this.height - VANILLA_BOOK_HEIGHT) / 2;
    }

    /**
     * 3-slice background renderer: left/right caps at native size,
     * middle section tiled horizontally.  Borders and shadows stay
     * sharp regardless of book width.
     * <p>
     * Vanilla recipe_book.png is 256×256 with the book background at
     * UV (1,1) size (147,166).  We slice it into:
     * <ul>
     *   <li>Left cap:  7px — left border, shadow, tab notches</li>
     *   <li>Body:     133px — fill area (tileable)</li>
     *   <li>Right cap: 7px — right border, shadow</li>
     * </ul>
     */
    private static final int BG_LEFT_CAP = 7;
    private static final int BG_RIGHT_CAP = 7;
    private static final int BG_BODY = VANILLA_BOOK_WIDTH - BG_LEFT_CAP - BG_RIGHT_CAP; // 133
    private static final int BG_TEX_SIZE = 256;

    private void brbe$renderBookBackground(GuiGraphics gui, int x, int y, int bookWidth) {
        var tex = BRBTextures.RECIPE_BOOK_BACKGROUND_TEXTURE;

        if (!isExpanded() || bookWidth <= VANILLA_BOOK_WIDTH) {
            // Normal mode: single blit at native size
            gui.blit(tex, x, y, 0, 0, VANILLA_BOOK_WIDTH, VANILLA_BOOK_HEIGHT, BG_TEX_SIZE, BG_TEX_SIZE);
            return;
        }

        // Expanded mode: 3-slice

        // Left cap — native size, UV(0,0) in the texture
        gui.blit(tex, x, y, 0, 0, BG_LEFT_CAP, VANILLA_BOOK_HEIGHT, BG_TEX_SIZE, BG_TEX_SIZE);

        // Middle — tiled across the expanded gap
        int bodyStartX = x + BG_LEFT_CAP;
        int bodyEndX = x + bookWidth - BG_RIGHT_CAP;
        int bodyWidth = bodyEndX - bodyStartX;
        int srcBodyX = BG_LEFT_CAP;  // UV start for the body section
        for (int bx = 0; bx < bodyWidth; bx += BG_BODY) {
            int segW = Math.min(BG_BODY, bodyWidth - bx);
            gui.blit(tex, bodyStartX + bx, y,
                    srcBodyX, 0, segW, VANILLA_BOOK_HEIGHT,
                    BG_TEX_SIZE, BG_TEX_SIZE);
        }

        // Right cap — native size, UV(140,0) in the texture
        int rightSrcX = VANILLA_BOOK_WIDTH - BG_RIGHT_CAP;
        gui.blit(tex, bodyEndX, y,
                rightSrcX, 0, BG_RIGHT_CAP, VANILLA_BOOK_HEIGHT,
                BG_TEX_SIZE, BG_TEX_SIZE);
    }

    /** The current rendered width of the recipe book — 147 normally, larger when expanded. */
    public int getCurrentBookWidth() {
        if (isExpanded()) {
            return Math.max(VANILLA_BOOK_WIDTH, getExpandedWidth());
        }
        return VANILLA_BOOK_WIDTH;
    }

    /** Compute the expanded width: from the book's normal left edge to the inventory's right edge. */
    protected int getExpandedWidth() {
        int leftPos;
        if (BetterRecipeBook.config.keepCentered) {
            // When centered, the inventory is at screen center
            leftPos = (this.width - this.containerImageWidth) / 2;
        } else {
            leftPos = findLeftEdge(this.width, this.containerImageWidth);
        }
        int inventoryRight = leftPos + this.containerImageWidth;
        int bookLeft = (this.width - VANILLA_BOOK_WIDTH) / 2 - this.xOffset;
        return inventoryRight - bookLeft;
    }

    /** Let the screen set the real container imageWidth for accurate width calculation. */
    public void setContainerImageWidth(int imageWidth) {
        this.containerImageWidth = imageWidth;
    }

    @Override
    @NotNull
    public NarratableEntry.NarrationPriority narrationPriority() {
        return this.isVisible() ? NarratableEntry.NarrationPriority.HOVERED : NarratableEntry.NarrationPriority.NONE;
    }

    protected void setVisible(boolean visible) {
        BrbeLogger.log(BrbeLogger.Category.VISIBILITY,
                "setVisible(%s) generic — current=%s, will call initVisuals=%s",
                visible, this.visible, visible && !this.visible);

        // Match vanilla behaviour: re-initialise when becoming visible.
        // The vanilla RecipeBookComponent.setVisible(true) calls initVisuals(),
        // which triggers updateCollections() and rebuilds all UI elements.
        // Without this, the recipe book can show stale state after a config
        // change if configChanged was consumed while the book was invisible.
        if (visible && !this.visible) {
            initVisuals();
        }

        BRBBookSettings.setOpen(getRecipeBookType(), visible);
        this.visible = visible;
    }

    public boolean isVisible() {
        return visible;
    }

    public void toggleVisibility() {
        this.setVisible(!this.isVisible());
    }

    public boolean hasClickedOutside(double d, double e, int i, int j, int k, int l, int m) {
        if (!this.isVisible()) {
            return true;
        }
        int bookWidth = getCurrentBookWidth();
        boolean bl = d < (double) i || e < (double) j || d >= (double) (i + k) || e >= (double) (j + l);
        boolean bl2 = (double) (i - bookWidth) < d && d < (double) i && (double) j < e && e < (double) (j + l);
        return bl && !bl2;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!this.isVisible()) return false;

        if (this.recipesPage.mouseClicked(mouseX, mouseY, button,
                getBookLeft(), getBookTop(),
                getCurrentBookWidth(), VANILLA_BOOK_HEIGHT)) {
            this.handlePlaceRecipe();
            return true;
        }

        if (this.searchBox.mouseClicked(mouseX, mouseY, button)) {
            searchBox.setFocused(true);
            ignoreTextInput = true;
            return true;
        }

        searchBox.setFocused(false);
        ignoreTextInput = false;

        if (this.filterButton.mouseClicked(mouseX, mouseY, button)) {
            boolean bl = this.toggleFiltering();
            this.filterButton.setStateTriggered(bl);
            this.updateFilterButtonTooltip();
            this.updateCollections(false);
            return true;
        }

        if (ISettingsButton.super.settingsButtonMouseClicked(this.settingsButton, mouseX, mouseY, button)) {
            return true;
        }

        if (this.expandedToggleButton != null
                && this.expandedToggleButton.mouseClicked(mouseX, mouseY, button)) {
            return true;
        }

        Iterator<BRBGroupButtonWidget> tabButtonsIter = this.tabButtons.iterator();

        BRBGroupButtonWidget widget;
        if (!tabButtonsIter.hasNext()) {
            return false;
        }

        widget = tabButtonsIter.next();
        while (!widget.mouseClicked(mouseX, mouseY, button)) {
            if (!tabButtonsIter.hasNext()) {
                return false;
            }

            widget = tabButtonsIter.next();
        }

        if (this.selectedTab != widget) {
            if (this.selectedTab != null) {
                this.selectedTab.setStateTriggered(false);
            }

            this.selectedTab = widget;
            this.selectedTab.setStateTriggered(true);
            this.updateCollections(true);
        }

        return false;
    }

    protected boolean toggleFiltering() {
        boolean bl = !BRBBookSettings.isFiltering(this.getRecipeBookType());
        BRBBookSettings.setFiltering(this.getRecipeBookType(), bl);

        return bl;
    }

    @Override
    public void updateNarration(NarrationElementOutput narrationElementOutput) {
    }

    @Override
    public void setFocused(boolean bl) {
    }

    @Override
    public boolean isFocused() {
        return false;
    }

    protected void updateFilterButtonTooltip() {
        this.filterButton.setTooltip(this.filterButton.isStateTriggered() ? Tooltip.create(this.getRecipeFilterName()) : Tooltip.create(ALL_RECIPES_TOOLTIP));
    }

    public int findLeftEdge(int width, int backgroundWidth) {
        int j;
        if (this.isVisible() && !this.widthTooNarrow) {
            j = 177 + (width - backgroundWidth - 200) / 2;
        } else {
            j = (width - backgroundWidth) / 2;
        }

        return j;
    }

    public void drawTooltip(GuiGraphics gui, int x, int y, int mouseX, int mouseY) {
        if (!this.isVisible()) {
            return;
        }

        if (!this.recipesPage.overlayIsVisible()) {
            this.recipesPage.drawTooltip(gui, mouseX, mouseY);

            ISettingsButton.super.renderSettingsButtonTooltip(this.settingsButton, gui, mouseX, mouseY);
        }

        this.ghostRecipe.drawTooltip(gui, x, y, mouseX, mouseY);
        this.brbe$lastHoveredGhostItem = this.ghostRecipe.getLastHoveredItem();
    }

    protected void refreshTabButtons() {
        int i = getBookLeft() - 30;
        int j = getBookTop() + 3;
        int l = 0;

        for (BRBGroupButtonWidget button : this.tabButtons) {
            BRBBookCategories.Category category = button.getCategory();
            if (category.getType() == BRBBookCategories.Category.Type.SEARCH) {
                button.visible = true;
            }
            button.setPosition(i, j + 27 * l++);
        }
    }

    /** Create or reposition the expanded-mode toggle button below the left-side tabs. */
    protected void refreshExpandedToggleButton() {
        int tabX = getBookLeft() - 30;
        int tabY = getBookTop() + 3;
        int buttonY = tabY + 27 * this.tabButtons.size() + 3; // below last tab + gap

        if (this.expandedToggleButton == null) {
            this.expandedToggleButton = new ImageButton(
                    tabX, buttonY, 20, 18,
                    BRBTextures.RECIPE_BOOK_BUTTON_SPRITES,
                    button -> {
                        BetterRecipeBook.config.expandedRecipeBook =
                                !BetterRecipeBook.config.expandedRecipeBook;
                        BetterRecipeBook.configChanged = true;
                        // Force visual rebuild
                        initVisuals();
                    });
        } else {
            this.expandedToggleButton.setPosition(tabX, buttonY);
        }
    }

    public void renderGhostRecipe(GuiGraphics guiGraphics, int x, int y, boolean bl, float delta) {
        if (selectedTab == null || ghostRecipe == null) return;

        this.ghostRecipe.render(guiGraphics, this.minecraft, x, y, bl, delta, selectedTab.getCategory());
    }

    protected abstract List<C> getCollectionsForCategory();

    @Override
    public void recipesShown(List<RecipeHolder<?>> list) {

    }
}
