package com.alonie.brbe.brewingstand.fabric;

import com.alonie.brbe.brewingstand.PlatformPotionUtil;
import com.alonie.brbe.fabric.Mixins.Accessors.FabricPotionBrewingAccessor;
import java.util.List;
import net.minecraft.class_1842;
import net.minecraft.class_1845;
import net.minecraft.class_1856;
import net.minecraft.class_638;

public class PlatformPotionUtilImpl implements PlatformPotionUtil.PotionUtilProvider {

    public static void init() {
        PlatformPotionUtil.setProvider(new PlatformPotionUtilImpl());
    }

    @Override
    public class_1856 getIngredient(Object recipe) {
        return ((class_1845.class_1846<?>) recipe).comp_2191();
    }

    @Override
    public class_1842 getTo(Object recipe) {
        return ((class_1845.class_1846<class_1842>) recipe).comp_2192().comp_349();
    }

    @Override
    public class_1842 getFrom(Object recipe) {
        return ((class_1845.class_1846<class_1842>) recipe).comp_2190().comp_349();
    }

    @Override
    public List<?> getPotionMixes(class_638 level) {
        class_1845 brewing = level.method_59547();
        return ((FabricPotionBrewingAccessor) brewing).getPotionMixes();
    }
}
