package com.alonie.brbe.fabric.compat.jei;

import com.alonie.brbe.BetterRecipeBook;
import com.alonie.brbe.compat.jei.JeiCompat;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.ingredients.ITypedIngredient;
import mezz.jei.api.recipe.IFocus;
import mezz.jei.api.recipe.IFocusFactory;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.runtime.IJeiRuntime;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import java.util.List;
import java.util.Optional;

@JeiPlugin
public final class BetterRecipeBookJEIPlugin implements IModPlugin {
    private static final class_2960 PLUGIN_UID = class_2960.method_60655(BetterRecipeBook.MOD_ID, "jei");

    @Override
    public class_2960 getPluginUid() {
        return PLUGIN_UID;
    }

    @Override
    public void onRuntimeAvailable(IJeiRuntime jeiRuntime) {
        JeiCompat.setHandler(new JeiCompat.JeiHandler() {
            @Override
            public boolean openRecipeView(class_1799 stack) {
                return open(jeiRuntime, RecipeIngredientRole.OUTPUT, stack);
            }

            @Override
            public boolean openUsageView(class_1799 stack) {
                return open(jeiRuntime, RecipeIngredientRole.INPUT, stack);
            }
        });
    }

    @Override
    public void onRuntimeUnavailable() {
        JeiCompat.setHandler(null);
    }

    private static boolean open(IJeiRuntime jeiRuntime, RecipeIngredientRole role, class_1799 stack) {
        if (stack.method_7960()) {
            return false;
        }

        Optional<ITypedIngredient<class_1799>> typedIngredient = jeiRuntime.getIngredientManager()
                .createTypedIngredient(VanillaTypes.ITEM_STACK, stack, false);
        if (typedIngredient.isEmpty()) {
            return false;
        }

        IFocusFactory focusFactory = jeiRuntime.getJeiHelpers().getFocusFactory();
        IFocus<class_1799> focus = focusFactory.createFocus(role, typedIngredient.get());
        jeiRuntime.getRecipesGui().show(List.of(focus));
        return true;
    }
}
